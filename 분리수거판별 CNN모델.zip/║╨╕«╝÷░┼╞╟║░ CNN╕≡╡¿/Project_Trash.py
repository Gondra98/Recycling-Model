import cv2
import os, glob
import matplotlib.pyplot as plt
import numpy as np
from keras.layers import MaxPooling2D, Dropout
from keras.saving.saving_api import load_model
from keras.callbacks import Callback
from keras.utils.np_utils import to_categorical
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.applications.densenet import layers

image_size = (128, 128)
image_folder = 5;
path = os.path.dirname(os.path.abspath(__file__))

Trash_Xdata = []
Trash_Ylabel = []
path_Trash = []

Trash_label = ["glass", "metal", "paper", "plastic", "cardboard"]

class Project_Trash:
    def ClassficationAndLabeling(self):                         #이미지분류 및 레이블링
        for i in range(0, image_folder):
            path_Trash = path + '/Trash' + str(i)
            Trash_img_files = glob.glob(path_Trash + "/*.jpg")
            for j in Trash_img_files:
                Trash_img = cv2.imread(j)
                Trash_img = cv2.resize(Trash_img, image_size)
                Trash_Xdata.append(Trash_img)
                Trash_Ylabel.append(i)

        if i == image_folder-1:
            for j in range(0, 25):
                plt.figure()
                plt.imshow(Trash_Xdata[j])
                plt.show()

    def trashModel(self):                                   # CNN모델

        class myCallback(Callback):
            def on_epoch_end(self, epoch, logs=None):
                if logs.get('loss') < 0.05:
                    print('\n Stop training.')
                    self.model.stop_training = True

        callbacks = myCallback()

        imagedata = np.array(Trash_Xdata)
        imagelabel = np.array(Trash_Ylabel)
        train_images, test_images, train_labels, test_labels = train_test_split(imagedata, imagelabel, test_size=0.2)

        train_images = train_images.astype('float32') / 255.0
        test_images = test_images.astype('float32') / 255.0

        train_labels = to_categorical(train_labels)
        test_labels = to_categorical(test_labels)

        model = Sequential()
        model.add(layers.Conv2D(32, (5, 5), activation='relu', input_shape=(128, 128, 3)))
        model.add(layers.MaxPooling2D((2, 2)))
        model.add(Dropout(0.25))

        model.add(layers.Conv2D(64, (3, 3), activation='relu'))
        model.add(layers.MaxPooling2D((2, 2)))
        model.add(Dropout(0.25))

        model.add(layers.Conv2D(128, (3, 3), activation='relu'))
        model.add(MaxPooling2D((2, 2)))
        model.add(Dropout(0.25))

        model.add(layers.Flatten())
        model.add(layers.Dense(45, activation='relu'))
        model.add(layers.Dense(64, activation='relu'))
        model.add(layers.Dense(128, activation='relu'))
        model.add(layers.Dense(5, activation='softmax'))
        model.summary()

        model.compile(optimizer='sgd', loss='categorical_crossentropy', metrics=['accuracy'])  # optimizer='adam'

        history = model.fit(train_images, train_labels, epochs=18, batch_size=1, callbacks=[callbacks])

        plt.title('Accuracy')
        plt.plot(history.history['accuracy'])
        plt.show()

        plt.title('Loss')
        plt.plot(history.history['loss'])
        plt.show()

        loss_and_accuracy = model.evaluate(test_images, test_labels)

        print('accuracy=' + str(loss_and_accuracy[1]))
        print('loss' + str(loss_and_accuracy[0]))

        model.save('Trash_model.h5')

    def use_pc(self):                                       #pc로 입력받아 수행
        new_trash_model = load_model('Trash_model.h5')
        img_path = path + '/Capture'
        img_files = glob.glob(img_path + "/*.jpg")

        for img in img_files:
            frame = cv2.imread(img)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame = cv2.resize(frame, (128, 128))
            predicted_result = new_trash_model.predict(np.array([frame]))
            trash_predict = predicted_result[0]
            for i, trashClass in enumerate(trash_predict):
                print(Trash_label[i], '=', int(trashClass * 100))
            print('Predicted Result=', Trash_label[trash_predict.argmax()])
            plt.imshow(frame)
            tmp = "Prediction:" + Trash_label[trash_predict.argmax()]
            plt.title(tmp)
            plt.show()



my_project = Project_Trash()

my_project.ClassficationAndLabeling()
my_project.trashModel()
my_project.use_pc()

